#!/bin/bash

SOURCE_PATH=$(pwd)
export PYTHONPATH=$SOURCE_PATH:$PYTHONPATH
# source /vla/miniconda3/bin/activate groot
DEBUG=false
set -x

dataset_list=(
   "/mnt/workspace/datasets/RoboTwin2.0/dataset_lerobot/aloha-agilex_clean_50"
  
)
data_config=(
  "robotwin"
)
embodiment_tag_list=(
  "robotwin"
)
# ==== debug or normal mode switch ====
if [ "$DEBUG" = "true" ]; then
    export CUDA_VISIBLE_DEVICES=0
    echo "Debug mode"
    NUM_GPUS=1
    BATCH_SIZE=8
    WORKERS=0
else
    echo "Normal mode"
    export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
    NUM_GPUS=8
    BATCH_SIZE=20
    WORKERS=8
    num_epochs=10
fi




OUTPUT_DIR=/mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robotwin_ckpt/n1.5_nopretrain_finetuneVL_on_robotwin_v0.0

if [ ! -d "$OUTPUT_DIR" ]; then
  mkdir -p "$OUTPUT_DIR"
fi

script_path="$(realpath "$0")"
cp "$script_path" "$OUTPUT_DIR"

MODELPATH=/mnt/workspace/users/lijiayi/checkpoints/GR00T-N1.5-3B


python scripts/gr00t_finetune.py \
--dataset_path ${dataset_list[@]} \
--num-gpus $NUM_GPUS \
--batch-size $BATCH_SIZE \
--output-dir ${OUTPUT_DIR} \
--num-train-epochs $num_epochs \
--no-instr-use-episode-index \
--video-backend torchvision_av \
--dataloader_num_workers 8 \
--base_model_path $MODELPATH \
--report_to tensorboard \
--action_horizon 16 \
--save_steps 1000 \
--data-config "${data_config[@]}" \
--tune_visual \
--no-tune-llm \
--embodiment_tag "${embodiment_tag_list[@]}" \
--update_action_head 



