# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, field
import os


import numpy as np
import torch
from huggingface_hub import snapshot_download
from huggingface_hub.errors import HFValidationError, RepositoryNotFoundError

from gr00t.data.dataset import ModalityConfig
from gr00t.data.embodiment_tags import EmbodimentTag
from gr00t.data.schema import DatasetMetadata
from gr00t.data.transform.base import ComposedModalityTransform
from gr00t.model.gr00t_n1 import GR00T_N1_5


COMPUTE_DTYPE = torch.bfloat16


class BasePolicy(ABC):
    @abstractmethod
    def get_action(self, observations: Dict[str, Any]) -> Dict[str, Any]:
        """
        Abstract method to get the action for a given state.

        Args:
            observations: The observations from the environment.

        Returns:
            The action to take in the environment in dictionary format.
        """
        raise NotImplementedError

    @abstractmethod
    def get_modality_config(self) -> Dict[str, ModalityConfig]:
        """
        Return the modality config of the policy.
        """
        raise NotImplementedError


class Gr00tPolicy(BasePolicy):
    """
    A wrapper for Gr00t model checkpoints that handles loading the model, applying transforms,
    making predictions, and unapplying transforms. This loads some custom configs, stats
    and metadata related to the model checkpoints used
    in the Gr00t model.
    """

    def __init__(
        self,
        model_path: str,
        embodiment_tag: Union[str, EmbodimentTag],
        modality_config: Dict[str, ModalityConfig],
        modality_transform: ComposedModalityTransform,
        denoising_steps: Optional[int] = None,
        device: Union[int, str] = "cuda" if torch.cuda.is_available() else "cpu",
        action_horizon=None,
        enable_latent_embedding=False,
        backbone_type=None,
        backbone_model_name_or_path=None,
        use_dino=False,
        use_time_aware_action_head=False,
        use_eepose=False,
    ):
        """
        Initialize the Gr00tPolicy.

        Args:
            model_path (str): Path to the model checkpoint directory or the huggingface hub id.
            modality_config (Dict[str, ModalityConfig]): The modality config for the model.
            modality_transform (ComposedModalityTransform): The modality transform for the model.
            embodiment_tag (Union[str, EmbodimentTag]): The embodiment tag for the model.
            denoising_steps: Number of denoising steps to use for the action head.
            device (Union[int, str]): Device to run the model on.
        """
        try:
            # NOTE(YL) this returns the local path to the model which is normally
            # saved in ~/.cache/huggingface/hub/
            model_path = snapshot_download(model_path, repo_type="model")
            # HFValidationError, RepositoryNotFoundError
        except (HFValidationError, RepositoryNotFoundError):
            print(
                f"Model not found or avail in the huggingface hub. Loading from local path: {model_path}"
            )

        self._modality_config = modality_config
        self._modality_transform = modality_transform
        self._modality_transform.eval()  # set this to eval mode
        self.model_path = Path(model_path)
        self.device = device

        # Convert string embodiment tag to EmbodimentTag enum if needed
        if isinstance(embodiment_tag, str):
            self.embodiment_tag = EmbodimentTag(embodiment_tag)
        else:
            self.embodiment_tag = embodiment_tag

        # Load model
        self._load_model(model_path, 
                         backbone_type=backbone_type, 
                         enable_latent_alignment=enable_latent_embedding, 
                         use_dino=use_dino,
                         use_time_aware_action_head=use_time_aware_action_head,
                         )

        if action_horizon is not None:
            self.model.update_action_horizon(action_horizon)

        # Load transforms
        self._load_metadata(self.model_path / "experiment_cfg")
        # Load horizons
        self._load_horizons()

        if denoising_steps is not None:
            if hasattr(self.model, "action_head") and hasattr(
                self.model.action_head, "num_inference_timesteps"
            ):
                self.model.action_head.num_inference_timesteps = denoising_steps
                print(f"Set action denoising steps to {denoising_steps}")

        self.use_eepose = use_eepose
        print(f"debug policy : is use eepose :{self.use_eepose}")
        if self.use_eepose:
            
            if "robocasa" in self.embodiment_tag.value:
                from gr00t.eval.gr1_pos_transform import BodyRetargeter, GR1RetargetConfig
                gr1_config = GR1RetargetConfig()
                
                # 然后，通过这个实例来访问属性
                self.body_retargeter = BodyRetargeter(
                    urdf_path=Path(gr1_config.urdf_path), 
                    camera_intrinsics=gr1_config.camera_intrinsics
                )
                print("Enabled Robocasa EEPose processing in Gr00tPolicy.")
            elif "robotwin" in self.embodiment_tag.value:
                from gr00t.eval.robotwin_aloha_transform_kdl import AlohaRetargeter, RobotwinRetargetConfig
                robotwin_config = RobotwinRetargetConfig()
                self.body_retargeter = AlohaRetargeter(
                    urdf_path=Path(robotwin_config.urdf_path),                )
                print("Enabled Robotwin EEPose processing in Gr00tPolicy.")


    def apply_transforms(self, obs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply transforms to the observation.

        Args:
            obs (Dict[str, Any]): The observation to transform.

        Returns:
            Dict[str, Any]: The transformed observation.
        """
        # Ensure correct dimensions before applying transforms
        return self._modality_transform(obs)

    def unapply_transforms(self, action: Dict[str, Any]) -> Dict[str, Any]:
        """
        Unapply transforms to the action.

        Args:
            action (Dict[str, Any]): The action to unapply transforms to.

        Returns:
            Dict[str, Any]: The untransformed action.
        """
        return self._modality_transform.unapply(action)
    
    def reset_ik_cache(self, env_idx: Optional[int] = None):
        """
        清空 Robocasa/GR1 EEPose IK 的历史缓存。
        env_idx=None 清空全部；否则只清对应并行 env slot。
        """
        if hasattr(self, "body_retargeter") and hasattr(self.body_retargeter, "reset_ik_cache"):
            self.body_retargeter.reset_ik_cache(env_idx)

    def get_action(self, observations: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a prediction with the model.
        Args:
            obs (Dict[str, Any]): The observation to make a prediction for.

        e.g. obs = {
            "video.<>": np.ndarray,  # (T, H, W, C)
            "state.<>": np.ndarray, # (T, D)
            "annotation.<>": np.ndarray, # (T, )
        }

        or with batched input:
        e.g. obs = {
            "video.<>": np.ndarray,, # (B, T, H, W, C)
            "state.<>": np.ndarray, # (B, T, D)
            "annotation.<>": np.ndarray, # (B, T, )
        }

        Returns:
            Dict[str, Any]: The predicted action.
        """
        # Create a copy to avoid mutating input
        obs_copy = observations.copy()
        left_arm_state = None
        right_arm_state = None
        # full_44dof_vector = None
        full_action_vector = None

        # ==========================================================
        # 新增：从 obs 里读取 reset 标记，清掉对应 env_idx 的 IK bucket
        # 约定：
        # - obs_copy["meta.reset_mask"] 或 obs_copy["reset_mask"]
        # - 形状为 (B,) 的 bool/int；True 表示该 slot 刚 reset（新 episode 开始）
        # ==========================================================
        reset_mask = None
        if "meta.reset_mask" in obs_copy:
            reset_mask = obs_copy.pop("meta.reset_mask", None)


        if reset_mask is not None:
            rm = np.asarray(reset_mask).astype(bool)
            if rm.ndim == 0:
                if bool(rm):
                    print("[Gr00tPolicy] reset_ik_cache env_idx=0 (scalar reset_mask)", flush=True)
                    self.reset_ik_cache(env_idx=0)
            else:
                rm = rm.reshape(-1)
                reset_envs = np.where(rm)[0].tolist()
                if reset_envs:
                    print(f"[Gr00tPolicy] reset_ik_cache env_idx={reset_envs}", flush=True)
                for env_idx, flag in enumerate(rm):
                    if bool(flag):
                        self.reset_ik_cache(env_idx=env_idx)


        """
        Robocasa:
            --- Debugging 'obs' for Robocasa arm_qpos ---
            Key: 'annotation.human.coarse_action', Type: <class 'list'>
            Key: 'state.left_arm', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 7), Dtype: float64
            Key: 'state.left_hand', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.right_arm', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 7), Dtype: float64
            Key: 'state.right_hand', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.waist', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 3), Dtype: float64
            Key: 'video.ego_view_pad_res256_freq20', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 256, 256, 3), Dtype: uint8
            Key: 'video.ego_view', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 256, 256, 3), Dtype: uint8
            ------------------------------------------------

            --- Debugging 'obs' for eepose ---
            Key: 'annotation.human.coarse_action', Type: <class 'list'>
            Key: 'state.left_arm', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.left_hand', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.right_arm', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.right_hand', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 6), Dtype: float64
            Key: 'state.waist', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 3), Dtype: float64
            Key: 'video.ego_view_pad_res256_freq20', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 256, 256, 3), Dtype: uint8
            Key: 'video.ego_view', Type: <class 'numpy.ndarray'>, Shape: (5, 1, 256, 256, 3), Dtype: uint8
            ------------------------------------------------
        
        Robotwin:
            --- Debugging 'obs' for eepose ---
            video.image_high: (1, 1, 480, 640, 3)
            video.image_left_wrist: (1, 1, 480, 640, 3)
            video.image_right_wrist: (1, 1, 480, 640, 3)
            state.left_arm: (1, 1, 6)
            state.left_gripper: (1, 1, 1)
            state.right_arm: (1, 1, 6)
            state.right_gripper: (1, 1, 1)
            annotation.human.task_description: (1,)
            ------------------------------------------------
        
        """

   
        is_batch = self._check_state_is_batched(obs_copy)

        if not is_batch:
            obs_copy = unsqueeze_dict_values(obs_copy)
        
        
        # print("=== action dict shapes ===")
        # for k, v in obs_copy.items():
        #     try:
        #         arr = np.asarray(v)
        #         print(f"{k}: {arr.shape}")
        #     except Exception:
        #         # 极少数不是 array 的就打印类型
        #         print(f"{k}: type={type(v)}")

            
        # Convert to numpy arrays
        for k, v in obs_copy.items():
            if not isinstance(v, np.ndarray):
                # 如果值是元组 (通常来自并行环境的文本观测)
                # 我们需要显式指定 dtype，以避免创建 object 类型的数组
                if isinstance(v, tuple):
                    obs_copy[k] = np.array(v, dtype=str)
                    # print(f"Converted tuple observation for key {k} from tuple to {obs_copy[k].dtype} with dtype str.")

                else:
                    obs_copy[k] = np.array(v)
        



        if self.use_eepose:
            if "robocasa" in self.embodiment_tag.value:
                # 1. 使用 BodyRetargeter 将 EEpose 转换为标准状态表示
                full_action_vector = self._build_full_44dof_vector(obs_copy)
                (left_hand_positions, left_hand_axisangles), (right_hand_positions, right_hand_axisangles), (left_qpos_states, right_qpos_states) = self.body_retargeter.process_frame_kinematics_axisangle(full_action_vector)
                # print(f"Left hand positions shape: {left_hand_positions.shape}, axis-angles shape: {left_hand_axisangles.shape}")
                # 2. 将转换后的状态添加回 obs_copy
                left_arm_state = obs_copy.get("state.left_arm", None)
                right_arm_state = obs_copy.get("state.right_arm", None)
                # 拼接两个 (bs, 3) 的数组，得到一个 (bs, 6) 的二维数组
                left_eepose_2d = np.concatenate((left_hand_positions, left_hand_axisangles), axis=-1)
                right_eepose_2d = np.concatenate((right_hand_positions, right_hand_axisangles), axis=-1)

                # 使用 np.newaxis 恢复时间维度，将其从 (bs, 6) 变为 (bs, 1, 6)
                obs_copy["state.left_arm"] = left_eepose_2d[:, np.newaxis, :]
                obs_copy["state.right_arm"] = right_eepose_2d[:, np.newaxis, :]
            
            elif "robotwin" in self.embodiment_tag.value:
                # print("Robotwin EE Pose processing in Gr00tPolicy.")
                # 单帧 14d
                full_action_vector = self._build_single_14dof_vector_robotwin(obs_copy)  # (14,)

                # FK -> 相机系 (pos, axis-angle)
                (left_pos, left_axis), (right_pos, right_axis), (left_q, right_q) = \
                    self.body_retargeter.process_frame_kinematics_axisangle(full_action_vector)

                # 保存原始 qpos（用于 IK seed）；这里 robotwin 是 (B,T,6)
                left_arm_state = obs_copy.get("state.left_arm", None)
                right_arm_state = obs_copy.get("state.right_arm", None)

                left_eepose_2d = np.concatenate((left_pos, left_axis), axis=-1)     # (B,6)
                right_eepose_2d = np.concatenate((right_pos, right_axis), axis=-1)  # (B,6)
                # print(f"Left eepose 2d: {left_eepose_2d}, Right eepose 2d: {right_eepose_2d}")

                obs_copy["state.left_arm"] = left_eepose_2d[:, np.newaxis, :]   # (B,1,6)
                obs_copy["state.right_arm"] = right_eepose_2d[:, np.newaxis, :] # (B,1,6)
                # print(f"Robotwin EE Pose processed: Left EE Pose shape: {obs_copy['state.left_arm'].shape},  Right EE Pose shape: {obs_copy['state.right_arm'].shape}")

            

        # Apply transforms
        normalized_input = self.apply_transforms(obs_copy)
        normalized_action = self._get_action_from_normalized_input(normalized_input)
        unnormalized_action = self._get_unnormalized_action(normalized_action)
        
        # print("\n --- Gr00tPolicy Debug Info ---")
        # for key , value in unnormalized_action.items():
        #     print(f"Action: {key}: {value.shape}")
        # print(" --- End of Debug Info --- \n")
        
        """
        Robocasa: 
            Action: action.left_arm: (5, 16, 7)
            Action: action.right_arm: (5, 16, 7)
            Action: action.left_hand: (5, 16, 6)
            Action: action.right_hand: (5, 16, 6)
            Action: action.waist: (5, 16, 3)
            
        Robotwin:
            Action: action.left_arm: (1, 16, 6)
            Action: action.right_arm: (1, 16, 6)
            Action: action.left_gripper: (1, 16, 1)
            Action: action.right_gripper: (1, 16, 1)

        """

        if not is_batch and "robocasa" in self.embodiment_tag.value:
            unnormalized_action = squeeze_dict_values(unnormalized_action) # 因为robocasa支持并行环境评测，而robotwin不支持并行环境评测
        else:
            pass

        if self.use_eepose:
            if "robocasa" in self.embodiment_tag.value:
                # 从模型输出的6-DoF EE Pose动作中提取 pos 和 axis-angle
                pred_left_eepose_seq = unnormalized_action["action.left_arm"]
                pred_right_eepose_seq = unnormalized_action["action.right_arm"]
                
                batch_size, horizon, _ = pred_left_eepose_seq.shape
                
                # 初始化用于存储IK结果的数组
                q_left_arm_seq = np.zeros((batch_size, horizon, 7)) # 目标是7-DoF
                q_right_arm_seq = np.zeros((batch_size, horizon, 7)) # 目标是7-DoF

                # 使用输入时的原始7-DoF手臂状态作为第一个时间步的IK初始猜测
                # 形状从 (B, 1, 7) 变为 (B, 7)
                q_init_left = left_arm_state[:, -1, :] if left_arm_state is not None else None
                q_init_right = right_arm_state[:, -1, :] if right_arm_state is not None else None

                # 遍历动作序列的每一个时间步 (从 0 到 15)
                for t in range(horizon):
                    # 提取当前时间步 t 的EE Pose动作，形状为 (B, 6)
                    left_eepose_t = pred_left_eepose_seq[:, t, :]
                    right_eepose_t = pred_right_eepose_seq[:, t, :]
                    # print(f"Time step {t}: Left EE Pose shape: {left_eepose_t.shape}, Right EE Pose shape: {right_eepose_t.shape}")

                    # 将EE Pose分解为位置和轴角
                    left_hand_pos = left_eepose_t[:, :3]
                    left_hand_axisangle = left_eepose_t[:, 3:6]
                    right_hand_pos = right_eepose_t[:, :3]
                    right_hand_axisangle = right_eepose_t[:, 3:6]

                    # 执行IK计算，输入是 (B, 3)，输出是 (B, 7)
                    q_left_arm_t, q_right_arm_t = self.body_retargeter.inverse_kinematics_from_camera_axisangle(
                        left_hand_pos=left_hand_pos,
                        left_hand_axisangle=left_hand_axisangle,
                        right_hand_pos=right_hand_pos,
                        right_hand_axisangle=right_hand_axisangle,
                        current_action_vector=full_action_vector,
                        q_init_left=q_init_left,
                        q_init_right=q_init_right
                    )

                    # 将计算出的关节角存储到结果序列中
                    if q_left_arm_t is not None:
                        q_left_arm_seq[:, t, :] = q_left_arm_t
                    if q_right_arm_t is not None:
                        q_right_arm_seq[:, t, :] = q_right_arm_t
                    
                    # 使用当前步的IK解作为下一步的初始猜测，以保证动作的连续性
                    q_init_left = q_left_arm_t
                    q_init_right = q_right_arm_t

                    # 打印每个chunk的值（按照data_config顺序：right_arm, right_hand, left_arm, left_hand）
                    batch_idx = 0  # 假设只有一个batch
                    right_arm = q_right_arm_seq[batch_idx, t, :]  # shape: (6,)
                    left_arm = q_left_arm_seq[batch_idx, t, :]    # shape: (6,)
                    
                    # # 打印robocasa的输出
                    # if "action.right_hand" in unnormalized_action:
                    #     right_hand = unnormalized_action["action.right_hand"][batch_idx, t, :]
                    #     left_hand = unnormalized_action["action.left_hand"][batch_idx, t, :]
                    #     # 按照data_config顺序拼接：right_arm + right_hand + left_arm + left_hand
                    #     concatenated = np.concatenate([right_arm, right_hand, left_arm, left_hand])
                    #     print(f"[Chunk {t}] right_arm={right_arm.tolist()} right_hand={right_hand.tolist()} "
                    #           f"left_arm={left_arm.tolist()} left_hand={left_hand.tolist()} "
                    #           f"concatenated={concatenated.tolist()}", flush=True)
                    # elif "action.right_gripper" in unnormalized_action:
                    #     right_gripper = unnormalized_action["action.right_gripper"][batch_idx, t, :]
                    #     left_gripper = unnormalized_action["action.left_gripper"][batch_idx, t, :]
                    #     # 按照data_config顺序拼接：right_arm + right_gripper + left_arm + left_gripper
                    #     concatenated = np.concatenate([right_arm, right_gripper, left_arm, left_gripper])
                    #     print(f"[Chunk {t}] right_arm={right_arm.tolist()} right_gripper={right_gripper.tolist()} "
                    #           f"left_arm={left_arm.tolist()} left_gripper={left_gripper.tolist()} "
                    #           f"concatenated={concatenated.tolist()}", flush=True)
                    # else:
                    #     # 如果没有hand/gripper，只打印arm
                    #     concatenated = np.concatenate([right_arm, left_arm])
                    #     print(f"[Chunk {t}] right_arm={right_arm.tolist()} left_arm={left_arm.tolist()} "
                    #           f"concatenated={concatenated.tolist()}", flush=True)

                # 将完整的关节角序列更新回 unnormalized_action 字典
                unnormalized_action["action.left_arm"] = q_left_arm_seq
                unnormalized_action["action.right_arm"] = q_right_arm_seq

            elif "robotwin" in self.embodiment_tag.value:
                # 从模型输出的6-DoF EE Pose动作中提取 pos 和 axis-angle
                pred_left_eepose_seq = unnormalized_action["action.left_arm"]
                pred_right_eepose_seq = unnormalized_action["action.right_arm"]
                # print(f"Pred Left EE Pose shape: {pred_left_eepose_seq.shape}, Pred Right EE Pose shape: {pred_right_eepose_seq.shape}")
                
                batch_size, horizon, _ = pred_left_eepose_seq.shape
                # print(f"Batch size: {batch_size}, Horizon: {horizon}")
                
                # --- 关键：robotwin/aloha 手臂是 6DoF；robocasa/gr1 仍按 7DoF ---
                q_out_dim = 6 
                # 初始化用于存储IK结果的数组
                q_left_arm_seq = np.zeros((batch_size, horizon, q_out_dim)) # 目标是q_out_dim
                q_right_arm_seq = np.zeros((batch_size, horizon, q_out_dim)) 

                # 使用输入时的原始7-DoF手臂状态作为第一个时间步的IK初始猜测
                # 形状从 (B, 1, 7) 变为 (B, 7)
                q_init_left = left_arm_state[:, -1, :q_out_dim] if left_arm_state is not None else None
                q_init_right = right_arm_state[:, -1, :q_out_dim] if right_arm_state is not None else None

                # 遍历动作序列的每一个时间步 (从 0 到 15)
                for t in range(horizon):
                    # 提取当前时间步 t 的EE Pose动作，形状为 (B, 6)
                    left_eepose_t = pred_left_eepose_seq[:, t, :]
                    right_eepose_t = pred_right_eepose_seq[:, t, :]
                    # print(f"Time step {t}: Left EE Pose shape: {left_eepose_t.shape}, Right EE Pose shape: {right_eepose_t.shape}")
                    # print(f"Left EE Pose: {left_eepose_t}, Right EE Pose: {right_eepose_t}")
                    # 将EE Pose分解为位置和轴角
                    left_hand_pos = left_eepose_t[:, :3]
                    left_hand_axisangle = left_eepose_t[:, 3:6]
                    right_hand_pos = right_eepose_t[:, :3]
                    right_hand_axisangle = right_eepose_t[:, 3:6]
                    # print(f"Time {t}: Left hand pos: {left_hand_pos}, Right hand pos: {right_hand_pos}")
                    # print(f"Time {t}: Left hand axisangle: {left_hand_axisangle}, Right hand axisangle: {right_hand_axisangle}")

                    # 执行IK计算，输入是 (B, 3)，输出是 (B, 7)
                    q_left_arm_t, q_right_arm_t = self.body_retargeter.inverse_kinematics_from_camera_axisangle(
                        left_hand_pos=left_hand_pos,
                        left_hand_axisangle=left_hand_axisangle,
                        right_hand_pos=right_hand_pos,
                        right_hand_axisangle=right_hand_axisangle,
                        current_action_vector=full_action_vector,
                        q_init_left=q_init_left,
                        q_init_right=q_init_right
                    )

                    # 将计算出的关节角存储到结果序列中
                    if q_left_arm_t is not None:
                        q_left_arm_seq[:, t, :] = q_left_arm_t[:, :q_out_dim] if q_left_arm_t.ndim == 2 else q_left_arm_t[:q_out_dim]
                    if q_right_arm_t is not None:
                        q_right_arm_seq[:, t, :] = q_right_arm_t[:, :q_out_dim] if q_right_arm_t.ndim == 2 else q_right_arm_t[:q_out_dim]
                    
                    # 使用当前步的IK解作为下一步的初始猜测，以保证动作的连续性
                    q_init_left = q_left_arm_t
                    q_init_right = q_right_arm_t
                    
                    



                # 将完整的关节角序列更新回 unnormalized_action 字典
                unnormalized_action["action.left_arm"] = q_left_arm_seq
                unnormalized_action["action.right_arm"] = q_right_arm_seq
                # Unnormalized Action: Left Arm shape: (1, 16, 6), Right Arm shape: (1, 16, 6)

        return unnormalized_action

    # Gr00t policy inference
    def _get_action_from_normalized_input(self, normalized_input: Dict[str, Any]) -> torch.Tensor:
        # Set up autocast context if needed
        with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=COMPUTE_DTYPE):
            model_pred = self.model.get_action(normalized_input)

        normalized_action = model_pred["action_pred"].float()
        return normalized_action

    def _get_unnormalized_action(self, normalized_action: torch.Tensor) -> Dict[str, Any]:
        return self.unapply_transforms({"action": normalized_action.cpu()})

    def get_modality_config(self) -> Dict[str, ModalityConfig]:
        """
        Get the modality config for the model, overrides the base class method
        """
        return self._modality_config

    @property
    def modality_config(self) -> Dict[str, ModalityConfig]:
        return self._modality_config

    @property
    def modality_transform(self) -> ComposedModalityTransform:
        return self._modality_transform

    @property
    def video_delta_indices(self) -> np.ndarray:
        """Get the video delta indices."""
        return self._video_delta_indices

    @property
    def state_delta_indices(self) -> np.ndarray | None:
        """Get the state delta indices."""
        return self._state_delta_indices

    @property
    def denoising_steps(self) -> int:
        """Get the number of denoising steps."""
        return self.model.action_head.num_inference_timesteps

    @denoising_steps.setter
    def denoising_steps(self, value: int):
        """Set the number of denoising steps."""
        self.model.action_head.num_inference_timesteps = value

    def _check_state_is_batched(self, obs: Dict[str, Any]) -> bool:
        for k, v in obs.items():
            if "state" in k and len(v.shape) < 3:  # (B, Time, Dim)
                return False
        return True

    def _load_model(self, model_path, 
                    backbone_type=None, 
                    enable_latent_alignment=None, 
                    use_dino=False, 
                    use_time_aware_action_head=False
                    ):
        if use_time_aware_action_head:
            model = GR00T_N1_5.from_pretrained(model_path, backbone_type=backbone_type, torch_dtype=COMPUTE_DTYPE,
                                            enable_latent_alignment=enable_latent_alignment,
                                            use_dino=use_dino,
                                            use_time_aware_action_head=use_time_aware_action_head,
                                            load_pretrained=True)
        else:
            model = GR00T_N1_5.from_pretrained(model_path, backbone_type=backbone_type, torch_dtype=COMPUTE_DTYPE,
                                            enable_latent_alignment=enable_latent_alignment,
                                            use_dino=use_dino,
                                            load_pretrained=False)

        model.eval()  # Set model to eval mode
        model.to(device=self.device)  # type: ignore

        self.model = model

    def _load_metadata(self, exp_cfg_dir: Path):
        """Load the transforms for the model."""
        # Load metadata for normalization stats
        metadata_path = exp_cfg_dir / "metadata.json"
        with open(metadata_path, "r") as f:
            metadatas = json.load(f)

        # Get metadata for the specific embodiment
        metadata_dict = metadatas.get(self.embodiment_tag.value)
        if metadata_dict is None:
            raise ValueError(
                f"No metadata found for embodiment tag: {self.embodiment_tag.value}",
                f"make sure the metadata.json file is present at {metadata_path}",
            )

        metadata = DatasetMetadata.model_validate(metadata_dict)

        self._modality_transform.set_metadata(metadata)
        self.metadata = metadata

    def _load_horizons(self):
        """Load the horizons needed for the model."""
        # Get modality configs
        # Video horizons
        self._video_delta_indices = np.array(self._modality_config["video"].delta_indices)
        self._assert_delta_indices(self._video_delta_indices)
        self._video_horizon = len(self._video_delta_indices)
        # State horizons (if used)
        if "state" in self._modality_config:
            self._state_delta_indices = np.array(self._modality_config["state"].delta_indices)
            self._assert_delta_indices(self._state_delta_indices)
            self._state_horizon = len(self._state_delta_indices)
        else:
            self._state_horizon = None
            self._state_delta_indices = None

    def _assert_delta_indices(self, delta_indices: np.ndarray):
        """Assert that the delta indices are valid."""
        # All delta indices should be non-positive because there's no way to get the future observations
        assert np.all(delta_indices <= 0), f"{delta_indices=}"
        # The last delta index should be 0 because it doesn't make sense to not use the latest observation
        assert delta_indices[-1] == 0, f"{delta_indices=}"
        if len(delta_indices) > 1:
            # The step is consistent
            assert np.all(
                np.diff(delta_indices) == delta_indices[1] - delta_indices[0]
            ), f"{delta_indices=}"
            # And the step is positive
            assert (delta_indices[1] - delta_indices[0]) > 0, f"{delta_indices=}"

    # 组成44DOF向量的辅助函数
    @staticmethod
    def _build_full_44dof_vector(obs_dict):
        """
        从包含批处理数据的观测字典中构建一个 (batch_size, 44) 的完整状态向量。
        
        Args:
            obs_dict (Dict[str, np.ndarray]): 观测字典，其中 state 的形状为 (B, T, D)。
                                              B 是批次大小 (环境数量), T 是时间步, D 是特征维度。

        Returns:
            np.ndarray: 形状为 (B, 44) 的状态向量。
        """
        # 定义44-DoF向量中每个部分的起始和结束索引
        layout_44dof = {
            "left_arm": (0, 7), "left_hand": (7, 13), "left_leg": (13, 19),
            "neck": (19, 22), "right_arm": (22, 29), "right_hand": (29, 35),
            "right_leg": (35, 41), "waist": (41, 44),
        }

        # 从任意一个存在的状态键确定批次大小
        batch_size = 0
        for key in obs_dict:
            if key.startswith("state."):
                batch_size = obs_dict[key].shape[0]
                break
        
        if batch_size == 0:
            # 如果没有找到任何 state key，无法确定批次大小，返回空数组或抛出错误
            # 这里我们假设至少会有一个 state key
            # 如果可能完全没有state，则需要根据具体情况处理
            # 例如，可以尝试从 "video" key 获取 batch_size
            if "video.ego_view" in obs_dict:
                 batch_size = obs_dict["video.ego_view"].shape[0]
            else: # 默认返回一个 (1, 44) 的零向量
                return np.zeros((1, 44), dtype=np.float64)


        # 初始化一个 (batch_size, 44) 的零矩阵
        full_vector = np.zeros((batch_size, 44), dtype=np.float64)

        # 遍历布局，填充 full_vector
        for part_name, (start, end) in layout_44dof.items():
            obs_key = f"state.{part_name}"
            
            if obs_key in obs_dict:
                # 提取数据，形状为 (B, T, D)
                data = np.asarray(obs_dict[obs_key])
                
                # 我们只关心最后一个时间步的数据，其形状为 (B, D)
                last_time_step_data = data[:, -1, :]
                
                # 将数据填充到 full_vector 的正确位置
                full_vector[:, start:end] = last_time_step_data
            # 如果 obs_key 不在字典中，则该部分将保持为零，符合要求

        return full_vector
    
    # 组成Robotwin/Aloha 14DOF向量的辅助函数（单帧）
    @staticmethod
    def _build_single_14dof_vector_robotwin(obs_dict) -> np.ndarray:
        """
        从观测字典中构建一个 (14,) 的 Robotwin/Aloha state 向量（单帧）。

        约定输出 layout：
        [left_arm(6), left_gripper(1), right_arm(6), right_gripper(1)]

        兼容输入 state 形状：
        - (B, T, D) 取最后一步 -> (B, D)，再取 batch=0 变成单帧
        - (T, D) / (D,) 也做兼容
        """
        layout_14dof = {
            "left_arm": (0, 6),
            "left_gripper": (6, 7),
            "right_arm": (7, 13),
            "right_gripper": (13, 14),
        }

        def _get_last_step(key: str):
            if key not in obs_dict:
                return None
            arr = np.asarray(obs_dict[key])

            # (B,T,D) -> (B,D)
            if arr.ndim == 3:
                arr = arr[:, -1, :]
                arr = arr[0]  # 取单帧 (D,)
            # (T,D) -> (D,)
            elif arr.ndim == 2:
                arr = arr[-1, :]
            # (D,) 保持
            elif arr.ndim == 1:
                pass
            else:
                raise ValueError(f"{key} 维度不支持: shape={arr.shape}")

            return np.asarray(arr, dtype=np.float64).reshape(-1)

        full_vec = np.zeros((14,), dtype=np.float64)

        # arm 必须存在
        la = _get_last_step("state.left_arm")
        ra = _get_last_step("state.right_arm")
        if la is None or ra is None:
            raise KeyError("robotwin 需要至少包含 state.left_arm 和 state.right_arm 来拼 14d state")

        # gripper：优先专用 key；否则退回用 hand 的第0维；都没有就置0
        lg = _get_last_step("state.left_gripper")
        rg = _get_last_step("state.right_gripper")
        if lg is None:
            lh = _get_last_step("state.left_hand")
            lg = lh[:1] if lh is not None else np.zeros((1,), dtype=np.float64)
        else:
            lg = lg[:1]

        if rg is None:
            rh = _get_last_step("state.right_hand")
            rg = rh[:1] if rh is not None else np.zeros((1,), dtype=np.float64)
        else:
            rg = rg[:1]

        # 填充
        full_vec[layout_14dof["left_arm"][0]:layout_14dof["left_arm"][1]] = la[:6]
        full_vec[layout_14dof["right_arm"][0]:layout_14dof["right_arm"][1]] = ra[:6]
        full_vec[layout_14dof["left_gripper"][0]:layout_14dof["left_gripper"][1]] = lg
        full_vec[layout_14dof["right_gripper"][0]:layout_14dof["right_gripper"][1]] = rg

        return full_vec
        

#######################################################################################################




# Helper functions
def unsqueeze_dict_values(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Unsqueeze the values of a dictionary.
    This converts the data to be batched of size 1.
    """
    unsqueezed_data = {}
    for k, v in data.items():
        if isinstance(v, np.ndarray):
            unsqueezed_data[k] = np.expand_dims(v, axis=0)
        elif isinstance(v, list):
            unsqueezed_data[k] = np.array(v)
        elif isinstance(v, torch.Tensor):
            unsqueezed_data[k] = v.unsqueeze(0)
        else:
            unsqueezed_data[k] = v
    return unsqueezed_data


def squeeze_dict_values(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Squeeze the values of a dictionary. This removes the batch dimension.
    """
    squeezed_data = {}
    for k, v in data.items():
        if isinstance(v, np.ndarray):
            squeezed_data[k] = np.squeeze(v)
        elif isinstance(v, torch.Tensor):
            squeezed_data[k] = v.squeeze()
        else:
            squeezed_data[k] = v
    return squeezed_data
