cd /mnt/workspace/users/lijiayi/robot_retarget_for_anything/body_retarget/pinocchio
mkdir build && cd build