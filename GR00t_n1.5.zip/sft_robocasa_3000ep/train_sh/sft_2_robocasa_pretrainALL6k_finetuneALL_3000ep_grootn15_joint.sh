#!/bin/bash
export JOB_NAME=$(hostname  | awk -F'-' '{print $1"-"$2}')
export JOB_LOGDIR=/mnt/workspace/job-logs/${JOB_NAME=$}
mkdir -p $JOB_LOGDIR


# 训练策略：采用预训练30wepisode，后训练10*300episode（30epoch，whole_bs=512）


# source /vla/miniconda3/bin/activate gr00t_n15
# 无论是运行挂载盘下的代码，还是运行容器内代码，注意进入工作目录。
cd /mnt/workspace/users/lijiayi/GR00T_QwenVLA
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

# 这个变量不起作用。
export NCCL_TIMEOUT=1800


RDMA_DEVICES=$(ls /sys/class/infiniband)
if [ -z "$RDMA_DEVICES" ]; then
  log "ERROR: No active RDMA devices found. Exiting script." >&2
  exit 1
fi

# 设置RDMA设备列表 (逗号分隔)
NCCL_IB_HCA=$(echo "$RDMA_DEVICES" | tr '\n' ',' | sed 's/,$//')
export NCCL_IB_HCA
echo "Detected RDMA devices: $NCCL_IB_HCA"

# 获取GID_INDEX
NCCL_IB_GID_INDEX=""
output=$(show_gids | grep v2)
# 遍历每一行
while IFS= read -r line; do
  ipv4=$(echo "$line" | awk '{print $5}')
  # 检查IPv4地址是否有值（不是空字符串且不是全0地址）
  if [[ -n "$ipv4" && "$ipv4" != "0000:0000:0000:0000:0000:ffff:0000:0000" && "$ipv4" =~ [0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]]; then
    NCCL_IB_GID_INDEX=$(echo "$line" | awk '{print $3}')
    # 找到第一个匹配项后立即退出循环
    break
  fi
done <<<"$output"

export NCCL_SOCKET_IFNAME="eth0"

# 处理分布式训练需要使用到的相关环境变量
export NCCL_IB_HCA=${NCCL_IB_HCA}
export NCCL_IB_GID_INDEX=${NCCL_IB_GID_INDEX}
export NCCL_NET_GDR_LEVEL=2
export NCCL_DEBUG_SUBSYS=ALL
export NCCL_IB_DISABLE=0
export NCCL_SOCKET_IFNAME=${NCCL_SOCKET_IFNAME}


SOURCE_PATH=$(pwd)
export PYTHONPATH=$SOURCE_PATH:$PYTHONPATH
# source /vla/miniconda3/bin/activate groot
DEBUG=false
set -x

# ==== 多节点配置 ====
# 总节点数（根据实际情况修改）
NUM_NODES=${PET_NNODES}
# 当前节点索引（0-based，每个节点启动时需指定不同值）
NODE_RANK=${PET_NODE_RANK}
# 主节点IP地址（确保所有节点可访问）
MASTER_ADDR=${PET_MASTER_ADDR}  # 替换为实际主节点IP
# 主节点端口（保持与代码中一致）
MASTER_PORT=${PET_MASTER_PORT}




dataset_list=(
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPBottleToCabinetClose_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPCanToDrawerClose_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPCupToDrawerClose_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPMilkToMicrowaveClose_GR1ArmsAndWaistFourierHands_1000"

    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPPotatoToMicrowaveClose_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PnPWineToCabinetClose_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromCuttingboardToBasketSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromCuttingboardToCardboardboxSplitA_GR1ArmsAndWaistFourierHands_1000"

    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromCuttingboardToPanSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromCuttingboardToPotSplitA_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromCuttingboardToTieredbasketSplitA_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlacematToBasketSplitA_GR1ArmsAndWaistFourierHands_1000"

    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlacematToBowlSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlacematToPlateSplitA_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlacematToTieredshelfSplitA_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlateToBowlSplitA_GR1ArmsAndWaistFourierHands_1000"

    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlateToCardboardboxSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlateToPanSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromPlateToPlateSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromTrayToCardboardboxSplitA_GR1ArmsAndWaistFourierHands_1000"

    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromTrayToPlateSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromTrayToPotSplitA_GR1ArmsAndWaistFourierHands_1000"
    "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromTrayToTieredbasketSplitA_GR1ArmsAndWaistFourierHands_1000"
    # "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300/gr1_unified.PosttrainPnPNovelFromTrayToTieredshelfSplitA_GR1ArmsAndWaistFourierHands_1000"
  )
data_config=(
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  "fourier_gr1_arms_waist"
  
)
embodiment_tag_list=(
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"
  "robocasa"

)

# ==== debug or normal mode switch ====
if [ "$DEBUG" = "true" ]; then
    export CUDA_VISIBLE_DEVICES=0
    echo "Debug mode"
    NUM_GPUS=1
    BATCH_SIZE=96
    WORKERS=0
else
    echo "Normal mode"
    # 每个节点使用的GPU（根据节点实际GPU数量调整）
    export CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
    NUM_GPUS_PER_NODE=8  # 每个节点的GPU数量
    NUM_GPUS=$NUM_GPUS_PER_NODE  # 补充定义：单节点的GPU数（用于条件判断）
    TOTAL_GPUS=$((NUM_NODES * NUM_GPUS_PER_NODE))  # 总GPU数量（多节点）
    # GPU: 87046MiB/97871MiB, 754/16382 [24:10<7:15:08,  1.67s/it]
    BATCH_SIZE=64  # 每个GPU的batch size
    WORKERS=8
fi

SAVE_STEPS=2000
num_epochs=30

OUTPUT_DIR=/mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robocasa_ckpt_10tasks_sample/n1.5_pretrainALL6k_finetuneALL_on_robocasa_joint_v0.1

if [ ! -d "$OUTPUT_DIR" ]; then
  mkdir -p "$OUTPUT_DIR"
fi

script_path="$(realpath "$0")"
cp "$script_path" "$OUTPUT_DIR"




#########################################################
# 后训练阶段:  微调vit
#########################################################

# 多节点训练使用torchrun启动

env IS_TORCHRUN=1 torchrun \
  --nnodes=$NUM_NODES \
  --node_rank=$NODE_RANK \
  --master_addr=$MASTER_ADDR \
  --master_port=$MASTER_PORT \
  --nproc_per_node=$NUM_GPUS_PER_NODE \
  scripts/gr00t_finetune.py \
  --dataset_path "${dataset_list[@]}" \
  --num-gpus $NUM_GPUS_PER_NODE \
  --batch-size $BATCH_SIZE \
  --output-dir $OUTPUT_DIR \
  --num-train-epochs $num_epochs \
  --no-instr-use-episode-index \
  --video-backend torchvision_av \
  --dataloader_num_workers $WORKERS \
  --base_model_path /mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/n1.5_pretrain_egohuman_fourier_tuneall_v0.0/checkpoint-6000 \
  --action_horizon 16 \
  --report_to tensorboard \
  --save_steps $SAVE_STEPS \
  --data-config "${data_config[@]}" \
  --tune_visual \
  --tune-llm \
  --embodiment_tag "${embodiment_tag_list[@]}" \
  --update_action_head 2>&1 | tee ${JOB_LOGDIR}/$(hostname).log





