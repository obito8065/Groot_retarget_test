#!/bin/bash
# 测评GR00t-n15的使用默认的joint数据 for robocasa:
cd /mnt/workspace/users/lijiayi/GR00T_QwenVLA

# 设置渲染环境变量（用于headless环境）
export LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
export PYOPENGL_PLATFORM=egl
export MUJOCO_GL=egl

python3 scripts/batch_robocasa_eval.py \
    --model_path /mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robocasa2egodex_ckpt_10tasks_sample/n1.5_pretrainVL6k_finetuneVL_on_robocasa_joint_v0.0/checkpoint-35970 \
    --embodiment_tag robocasa \
    --data_config fourier_gr1_arms_waist2egodex \
    --env_names \
        gr1_unified/PosttrainPnPNovelFromCuttingboardToBasketSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromCuttingboardToCardboardboxSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromCuttingboardToPotSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromPlacematToPlateSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromPlateToPanSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromPlateToPlateSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromTrayToCardboardboxSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromTrayToPlateSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromTrayToPotSplitA_GR1ArmsAndWaistFourierHands_Env \
        gr1_unified/PosttrainPnPNovelFromTrayToTieredbasketSplitA_GR1ArmsAndWaistFourierHands_Env \
    --base_port 54600 \
    --max_episode_steps 720 \
    --n_envs 10 \
    --n_episodes 100 \
    --base_video_dir /mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_video_record/output_robocasa2egodex_10tasks_sample/n1.5_6k_pretrainVL_finetuneVL_on_robocasa_joint_v0.1/35k-30epoch