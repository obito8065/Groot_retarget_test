

cd /mnt/workspace/users/lijiayi/GR00T_QwenVLA

python3 scripts/batch_robotwin_eval.py \
    --model_path /mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robotwin_easy_ckpt_3tasks/n1.5_pretrainALL_finetuneALL_on_robotwin_eepose_v0.2/checkpoint-12780 \
    --data_config robotwin_ego \
    --embodiment_tag robotwin \
    --task_names adjust_bottle place_burger_fries place_container_plate\
    --task_config demo_clean \
    --base_port 11316 \
    --seed_base 0 \
    --save_dir /mnt/workspace/users/lijiayi/GR00T_QwenVLA/outputs_robotwin/eval_result_3task_eepose/pretrainALL-30epoch \
    --gpu_ids 0 1 2\
    --tasks_per_gpu 1 \
    --n_episodes 100 \
    --use_eepose