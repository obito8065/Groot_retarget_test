#!/bin/bash

SOURCE_PATH=$(pwd)
export PYTHONPATH=$SOURCE_PATH:$PYTHONPATH


set -x
cd /mnt/workspace/users/lijiayi/GR00T_QwenVLA
dataset_list=(
    "/mnt/workspace/datasets/RoboTwin2.0/dataset_lerobot/aloha-agilex_clean_50"
)
data_config=(
  "robotwin"
)
embodiment_tag_list=(
  "robotwin"
)
NUM_GPUS=4
BATCH_SIZE=32
num_epochs=10
WORKERS=4
SAVE_STEPS=1000

OUTPUT_DIR=/mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robotwin_ckpt/n1.5_nopretrain_finetuneVL_on_robotwin_worker2_v0.1

if [ ! -d "$OUTPUT_DIR" ]; then
  mkdir -p "$OUTPUT_DIR"
fi

script_path="$(realpath "$0")"
cp "$script_path" "$OUTPUT_DIR"


MODELPATH=/mnt/workspace/users/lijiayi/checkpoints/GR00T-N1.5-3B

python scripts/gr00t_finetune.py \
--dataset_path "${dataset_list[@]}" \
--num-gpus $NUM_GPUS \
--batch-size $BATCH_SIZE \
--output-dir $OUTPUT_DIR \
--num-train-epochs $num_epochs \
--no-instr-use-episode-index \
--video-backend torchvision_av \
--dataloader_num_workers $WORKERS \
--base_model_path  $MODELPATH \
--action_horizon 16 \
--report_to tensorboard \
--save_steps $SAVE_STEPS \
--data-config "${data_config[@]}" \
--tune_visual \
--no-tune-llm \
--embodiment_tag "${embodiment_tag_list[@]}" \
--update_action_head 

