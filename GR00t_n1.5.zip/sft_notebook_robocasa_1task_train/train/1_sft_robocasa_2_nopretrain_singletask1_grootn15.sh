#!/bin/bash

SOURCE_PATH=$(pwd)
export PYTHONPATH=$SOURCE_PATH:$PYTHONPATH

# 指定GPU
export CUDA_VISIBLE_DEVICES=3
set -x
cd /mnt/workspace/users/lijiayi/GR00T_QwenVLA
dataset_list=(
      "/mnt/workspace/datasets/robocasa_24tasks_datasets/pick_and_place_lerobot_task24_sampled_300_epose/gr1_unified.PosttrainPnPNovelFromCuttingboardToBasketSplitA_GR1ArmsAndWaistFourierHands_300ee"

)
data_config=(
  "fourier_gr1_arms_waist"
)
embodiment_tag_list=(
   "robocasa"
)
NUM_GPUS=1
BATCH_SIZE=128
num_epochs=30
WORKERS=2
SAVE_STEPS=2000

OUTPUT_DIR=/mnt/workspace/users/lijiayi/GR00T_QwenVLA/output_ckpt/output_robocasa_ckpt_1tasks_sample/n1.5_nopretrain_finetuneALL_on_robocasa_v0.3

if [ ! -d "$OUTPUT_DIR" ]; then
  mkdir -p "$OUTPUT_DIR"
fi

script_path="$(realpath "$0")"
cp "$script_path" "$OUTPUT_DIR"


MODELPATH=/mnt/workspace/users/lijiayi/checkpoints/GR00T-N1.5-3B

python scripts/gr00t_finetune.py \
--dataset_path "${dataset_list[@]}" \
--num-gpus $NUM_GPUS \
--batch-size $BATCH_SIZE \
--output-dir $OUTPUT_DIR \
--num-train-epochs $num_epochs \
--no-instr-use-episode-index \
--video-backend torchvision_av \
--dataloader_num_workers $WORKERS \
--base_model_path  $MODELPATH \
--action_horizon 16 \
--report_to tensorboard \
--save_steps $SAVE_STEPS \
--data-config "${data_config[@]}" \
--tune_visual \
--tune-llm \
--embodiment_tag "${embodiment_tag_list[@]}" \
--update_action_head 

